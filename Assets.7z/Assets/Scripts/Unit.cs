using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Unit : MonoBehaviour
{
    private string _code;
    private int _healthpoints;
    private int _dmg;
    private float _speed;
    private bool _rangeattack;
    private int _armor;
    private float _piercing;
    private int _exp;
    private int _lvl;
    private int _buildcost;
    private int _timecost;


    public Unit(string code, int healthpoints, int dmg, float speed, bool rangeattack, int armor, float piercing, int exp, int lvl, int buildcost, int timecost)
    {
        _code = code;
        _healthpoints = healthpoints;
        _dmg = dmg;
        _speed = speed;
        _rangeattack = rangeattack;
        _armor = armor;
        _piercing = piercing;
        _exp = exp;
        _lvl = lvl;
        _buildcost = buildcost;
        _timecost = timecost;
    }

    public string Code { get => _code; }
    public int HP { get => _healthpoints; }
    public int DMG { get => _dmg; }
    public float Speed { get => _speed; }
    public bool RangeAttack { get => _rangeattack; }
    public int Armor { get => _armor; }
    public float Piercing { get => _piercing; }
    public int EXP { get => _exp; }
    public int LVL { get => _lvl; }
    public int BuildCost { get => _buildcost; }
    public int TimeCost { get => _timecost; }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            Vector2 mousePos2D = new Vector2(mousePos.x, mousePos.y);

            RaycastHit2D hit = Physics2D.Raycast(mousePos2D, Vector2.zero);
            if (hit.collider != null)
            {
                Debug.Log(hit.collider.gameObject.name);
                hit.collider.attachedRigidbody.AddForce(Vector2.up);
            }
        }
    }
}


